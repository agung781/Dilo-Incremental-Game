namespace UnityEngine.Purchasing
{
    /// <summary>
    /// Common interface for all purchasing extensions.
    /// </summary>
    public interface IStoreExtension
    {
    }
}
